import React, { useState } from 'react';

const SignUp = ({ onSignUp }) => {
  // Similar to Login.js, implement SignUp logic here

  return (
    <div>
      <h1>SignUp</h1>
      { 
      
      }
    </div>
  );
};

export default SignUp;
