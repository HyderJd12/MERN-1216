import React, { useState } from 'react';
import Login from "./Components/Login"
import SignUp from './Components/SignUp';
const TodoApp = () => {
  <>
  <Login></Login>
  <SignUp></SignUp>
  </>
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');

  const addTask = () => {
    if (newTask.trim() !== '') {
      setTasks([...tasks, { id: Date.now(), text: newTask }]);
      setNewTask('');
    }
  };

  const removeTask = (taskId) => {
    const updatedTasks = tasks.filter((task) => task.id !== taskId);
    setTasks(updatedTasks);
  };

  return (
    <div>
      <h1 className='title'>My To-Do list </h1>
      
      <div className='container'>
        
        <label> Type Your Task   </label>
      <div>
        <input className='inputtask'
          type="text"
          placeholder=' Enter your task here: '
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          />
        <button className='SubmitBtn' onClick={addTask}> Submit  </button>
        
        </div>
      </div>

  <table className='tab'>
  <thead>
    <tr>
      <th>ID</th>
      <th>Task</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    {tasks.map((task, index) => (
      <tr key={task.id}>
        <td>{index + 1}</td>
        <td>{task.text}</td>        
        <td>
        {/* <button className='removebtn' onClick={() => EditTask(task.id)}>
          EDIT
        </button> */}
          <button className='removebtn' onClick={() => removeTask(task.id)}>
          REMOVE
          </button>
          
        </td>
      </tr>
    ))}
  </tbody>
</table>

    </div>
  );
};

export default TodoApp;
