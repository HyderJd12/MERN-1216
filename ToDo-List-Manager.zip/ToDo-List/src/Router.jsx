// Router.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Redirect, Switch } from 'react-router-dom';
import Login from './Login';
import SignUp from './SignUp';
import TodoApp from './TodoApp';

const AppRouter = () => {
  const [authenticated, setAuthenticated] = useState(false);

  const handleLogin = () => {
    setAuthenticated(true);
  };

  const handleLogout = () => {
    setAuthenticated(false);
  };

  return (
    <Router>
      <Switch>
        <Route path="/login" render={() => <Login onLogin={handleLogin} />} />
        <Route path="/signUp" component={SignUp} />
        <PrivateRoute path="/project" component={TodoApp} isAuthenticated={authenticated} />
        <Redirect from="/" to="/login" />
      </Switch>
    </Router>
  );
};

const PrivateRoute = ({ component: Component, isAuthenticated, ...rest }) => (
  <Route
    {...rest}
    render={(props) => (isAuthenticated ? <Component {...props} /> : <Redirect to="/login" />)}
  />
);

export default AppRouter;
