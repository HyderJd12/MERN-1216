import React, { useState, useEffect } from 'react';

const TodoApp = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');

  useEffect(() => {
    fetch('/api/tasks')
      .then((res) => res.json())
      .then((data) => setTasks(data))
      .catch((error) => console.error('Error fetching tasks:', error));
  }, []);

  const addTask = () => {
    if (newTask.trim() !== '') {
      fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: newTask }),
      })
        .then((res) => res.json())
        .then((data) => setTasks([...tasks, data]))
        .catch((error) => console.error('Error adding task:', error));

      setNewTask('');
    }
  };

  const removeTask = (taskId) => {
    fetch(`/api/tasks/${taskId}`, {
      method: 'DELETE',
    })
      .then(() => setTasks(tasks.filter((task) => task._id !== taskId)))
      .catch((error) => console.error('Error deleting task:', error));
  };

  // Rest of your component code...
};

export default TodoApp;
